export { FeaturedCourses } from './LatestVideos'
